import { Component, OnInit } from '@angular/core';
import { ICar } from './car';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  templateUrl: './car-detail.component.html',
  styleUrls: ['./car-detail.component.css']
})
export class CarDetailComponent implements OnInit {
  pageTitle: string = 'Car Detail';
  car: ICar = {
    "carId": 2,
    "carName": "Toyota RAV4",
    "carCode": "CAR-0023",
    "releaseDate": "March 18, 2019",
    "description": "rav4",
    "price": 35000,
    "starRating": 2.1,
    "imageUrl": "assets/images/rav4.jpeg"

   };;
  constructor(private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    let id = +this.route.snapshot.paramMap.get('id');
    this.pageTitle += ` car ${id} was selected!`;
  }

  OnBack(): void {
    this.router.navigate(['/cars']);
  }

}
