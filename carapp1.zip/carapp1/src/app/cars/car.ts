export interface ICar {
    carId: number;
    carName: string;
    carCode: string;
    releaseDate: string;
    price: number;
    description: string;
    starRating: number;
    imageUrl: string;

    //calculate(year: number):number;
  
}