import { Injectable } from "@angular/core";
import { ICar } from "./car";
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})    
export class CarService {
    private url = '/api/cars/cars.json';
    constructor(private http: HttpClient) {

    }
    getCars(): Observable<ICar[]> {
       return this.http.get<ICar[]>(this.url).pipe(
        tap(data => console.log('All: ' + JSON.stringify(data))),
        catchError(this.handleError)
       );  
    }
    
  
  private handleError(err: HttpErrorResponse) {
      let errorMessage = '';
      if (err.error instanceof ErrorEvent){
        errorMessage = `an error occoured: ${err.error.message}`;
      }
      else{
        errorMessage = `Server error: ${err.status} ${err.error.message}`;
      }
      console.error(errorMessage);
      return throwError(errorMessage);
  };
  

}