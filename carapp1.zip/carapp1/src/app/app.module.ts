import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { CarListComponent } from './cars/car-list.component';
import { ConvertToDashPipe } from './shared/convert-to-dash.pipe';
import { StarComponent } from './shared/star.component';
import { CarService } from './cars/car.service';
import {HttpClientModule} from '@angular/common/http';
import { WelcomeComponent } from './home/welcome.component';
import { CarDetailComponent } from './cars/car-detail.component';
import { RouterModule} from '@angular/router';
import { CarDetailGuard } from './cars/car-detail.guard';

@NgModule({
  declarations: [
    AppComponent,
    CarListComponent,
    ConvertToDashPipe,
    StarComponent,
    WelcomeComponent,
    CarDetailComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    HttpClientModule,
    RouterModule.forRoot([
      { path: 'cars', component: CarListComponent},
      { path: 'cars/:id', component: CarDetailComponent, canActivate: [CarDetailGuard]},
      { path: 'welcome', component: WelcomeComponent},
      { path: '', redirectTo: 'welcome', pathMatch: 'full'},
      { path: '**', redirectTo: 'welcome', pathMatch: 'full'}

    ]), 
  ],
  providers: [
    //CarService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
